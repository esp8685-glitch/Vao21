/*
 * SPDX-FileCopyrightText: 2026 Suwatchai K. <suwatchai@outlook.com>
 *
 * SPDX-License-Identifier: MIT
 */

#ifndef BSSL_SSL_CLIENT_H
#define BSSL_SSL_CLIENT_H

#if defined(ESP8266) && defined(MMU_EXTERNAL_HEAP)
#include <umm_malloc/umm_malloc.h>
#include <umm_malloc/umm_heap_select.h>
#define ESP_SSLCLIENT_ESP8266_USE_EXTERNAL_HEAP
#endif

#if defined(BSSL_BUILD_INTERNAL_CORE) || defined(BSSL_BUILD_PLATFORM_CORE)

#if defined(BSSL_BUILD_PLATFORM_CORE)
#include <list>
#include <errno.h>
#include <algorithm>
#include "StackThunk.h"
#include "lwip/opt.h"
#include "lwip/ip.h"
#include "lwip/tcp.h"
#include "lwip/inet.h"
#include "lwip/netif.h"

#if 1
#if !CORE_MOCK

// The BearSSL thunks in use for now
#define br_ssl_engine_recvapp_ack thunk_br_ssl_engine_recvapp_ack
#define br_ssl_engine_recvapp_buf thunk_br_ssl_engine_recvapp_buf
#define br_ssl_engine_recvrec_ack thunk_br_ssl_engine_recvrec_ack
#define br_ssl_engine_recvrec_buf thunk_br_ssl_engine_recvrec_buf
#define br_ssl_engine_sendapp_ack thunk_br_ssl_engine_sendapp_ack
#define br_ssl_engine_sendapp_buf thunk_br_ssl_engine_sendapp_buf
#define br_ssl_engine_sendrec_ack thunk_br_ssl_engine_sendrec_ack
#define br_ssl_engine_sendrec_buf thunk_br_ssl_engine_sendrec_buf

#endif
#endif

#endif

#if defined(BSSL_BUILD_INTERNAL_CORE)

using namespace bssl;

#elif defined(BSSL_BUILD_PLATFORM_CORE)

#include "BearSSLHelpers.h"
#include "Helper.h"
#include "CertStoreBearSSL.h"

using namespace BearSSL;

#if defined(ESP8266)

#include "PolledTimeout.h"
#if defined(ESP8266_CORE_SDK_V3_X_X)
#include <umm_malloc/umm_heap_select.h>
#endif

#if __has_include(<core_esp8266_version.h>)
#include <core_esp8266_version.h>
#endif

#endif

#endif

class BSSL_SSLClient : public Client
{
public:
    explicit BSSL_SSLClient(Client *client = nullptr)
    {
        setClient(client);
        mClear();
        mClearAuthenticationSettings();
#if !defined(SSLCLIENT_INSECURE_ONLY)
#if defined(ENABLE_FS)
        _certStore = nullptr; // Don't want to remove cert store on a clear, should be long lived
#endif
        _sk = nullptr;
#endif
#if defined(BSSL_BUILD_PLATFORM_CORE)
        stack_thunk_add_ref();
#endif
    }

    ~BSSL_SSLClient()
    {
        if (_basic_client)
        {
            if (_basic_client->connected())
                _basic_client->stop();
            _basic_client = nullptr;
        }
        mFreeSSL();
        mClearAuthenticationSettings();
#if defined(BSSL_BUILD_PLATFORM_CORE)
        stack_thunk_del_ref();
#endif
    }

    void setClient(Client *client, bool ssl = false)
    {
        _basic_client = client;
        _isSSLEnabled = ssl;
    }

    void setDebugLevel(int level)
    {
        if (level < esp_ssl_debug_none || level > esp_ssl_debug_dump)
            _debug_level = esp_ssl_debug_none;
        else
            _debug_level = level;
    }

    int connect(IPAddress ip, uint16_t port) override
    {
#if !defined(__AVR__)
        if (_isSSLEnabled && mIsSecurePort(port)) // SSL connect
            return connectSSL(ip, port);
#endif

        if (!mConnectBasicClient(nullptr, ip, port))
            return 0;

        _connect_with_ip = true;
        _session_ts = millis();

        return 1;
    }

    int connect(const char *host, uint16_t port) override
    {
#if !defined(__AVR__)
        if (_isSSLEnabled && mIsSecurePort(port))
            return connectSSL(host, port);
#endif

        if (!mConnectBasicClient(host, IPAddress(), port))
            return 0;

        _connect_with_ip = false;
        _session_ts = millis();

        return 1;
    }

    uint8_t connected() override
    {
        if (!mIsClientInitialized(false))
            return 0;

        if (!_secure)
            return _basic_client->connected();

        // check all of the error cases
        const auto c_con = _basic_client->connected();
        const auto br_con = br_ssl_engine_current_state(_eng) != BR_SSL_CLOSED && _is_connected;
        const auto wr_ok = getWriteError() == 0;
        // if we're in an error state, close the connection and set a write error
        if (br_con && !c_con)
        {
            // If we've got a write error, the client probably failed for some reason
            if (_basic_client->getWriteError())
            {
#if defined(ENABLE_DEBUG)
                char s_buffer[64];
                snprintf_P(s_buffer, sizeof(s_buffer), PSTR("Socket was unexpectedly interrupted. m_client error: %u"), (unsigned int)_basic_client->getWriteError());
                esp_ssl_debug_print(s_buffer, _debug_level, esp_ssl_debug_info, __func__);
#endif
                setWriteError(esp_ssl_write_error);
            }
            // Else tell the user the endpoint closed the socket on us (ouch)
            else
            {
#if defined(ENABLE_DEBUG)
                // esp_ssl_debug_print(PSTR("Socket was dropped unexpectedly (this can be an alternative to closing the connection)."), _debug_level, esp_ssl_debug_warn, func_name);
#endif
            }
        }
        else if (!wr_ok)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Not connected because write error is set."), _debug_level, esp_ssl_debug_error, __func__);
            mPrintClientError(getWriteError(), esp_ssl_debug_error, __func__);
#endif
        }

        return c_con && br_con;
    }

    void validate(const char *host, uint16_t port) { mConnectionValidate(host, IPAddress(), port); }

    void validate(IPAddress ip, uint16_t port) { mConnectionValidate(nullptr, ip, port); }

    /**
     * @brief Checks if the current connection is encrypted (SSL/TLS).
     * @return bool True if SSL/TLS is enabled and active, false otherwise (plain TCP).
     */
    bool isSecure() const
    {
        return _secure;
    }

    int available() override
    {
        if (!mIsClientInitialized(false))
            return 0;

        // ssl engine receive buffer is available
        if (_recvapp_len > 0)
            return (int)_recvapp_len;
        else if (!_secure)
            return _basic_client->available();

        // connection check
        if (!mSoftConnected(__func__))
            return 0;

        // run the SSL engine until we are waiting for either user input or a server response
        unsigned state = mUpdateEngine();
        if (state == 0)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("SSL engine failed to update."), _debug_level, esp_ssl_debug_error, __func__);
#endif
        }
        else if (state & BR_SSL_RECVAPP)
        {
            // return how many received bytes we have
            _recvapp_buf = br_ssl_engine_recvapp_buf(_eng, &_recvapp_len);
            return (int)(_recvapp_len);
        }
        else if (state == BR_SSL_CLOSED)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("SSL Engine closed after update."), _debug_level, esp_ssl_debug_info, __func__);
#endif
        }
        // flush the buffer if it's stuck in the SENDAPP state
        else if (state & BR_SSL_SENDAPP)
            br_ssl_engine_flush(_eng, 0);
        // other state, or client is closed
        return 0;
    }

    int read() override
    {
        uint8_t read_val;
        return read(&read_val, 1) > 0 ? read_val : -1;
    }

    int read(uint8_t *buf, size_t size) override
    {
        if (!mIsClientInitialized(false))
            return -1;

        // plain mode: delegate to basic client if no SSL data remains
        if (!_secure && _recvapp_len == 0)
            return _basic_client->read(buf, size);

        // This ensures the engine runs and updates _recvapp_buf / _recvapp_len
        if (available() <= 0 || !size)
            return -1;

        // Check if the engine gave us data to read.
        if (_recvapp_len == 0 || _recvapp_buf == nullptr)
            return -1;

        // Determine actual read amount
        const size_t read_amount = size > _recvapp_len ? _recvapp_len : size;

        if (buf && read_amount > 0)
            memcpy(buf, _recvapp_buf, read_amount);

        // CRITICAL: Acknowledge consumed data AND manually advance the local pointer.
        // The ack updates the internal BearSSL consumed counter.
        br_ssl_engine_recvapp_ack(_eng, read_amount);

        // Advance the local pointer to the next unread byte (relative to the current block)
        // And decrease the remaining length.
        _recvapp_buf += read_amount;
        _recvapp_len -= read_amount;

        return read_amount;
    }

    size_t write(const uint8_t *buf, size_t size) override
    {
        if (!mIsClientInitialized(false))
            return 0;

        if (!mCheckSessionTimeout())
            return 0;

        _session_ts = millis();

        if (!_secure)
            return _basic_client->write(buf, size);

#if defined(ENABLE_DEBUG)
        // super debug
        if (_debug_level >= esp_ssl_debug_dump)
            DEBUG_PORT.write(buf, size);
#endif

        const char *func_name = __func__;
        // check if the socket is still open and such
        if (!mSoftConnected(func_name) || !buf || !size)
            return 0;
        // wait until bearssl is ready to send
        if (mRunUntil(BR_SSL_SENDAPP) < 0)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Failed while waiting for the engine to enter BR_SSL_SENDAPP."), _debug_level, esp_ssl_debug_error, func_name);
#endif
            return 0;
        }
        // add to the bearssl io buffer, simply appending whatever we want to write
        size_t alen;
        unsigned char *br_buf = br_ssl_engine_sendapp_buf(_eng, &alen);
        size_t cur_idx = 0;
        if (alen == 0)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("BearSSL returned zero length buffer for sending, did an internal error occur?"), _debug_level, esp_ssl_debug_error, func_name);
#endif
            return 0;
        }
        // while there are still elements to write
        while (cur_idx < size)
        {
            // if we're about to fill the buffer, we need to send the data and then wait
            // for another oppurtinity to send
            // so we only send the smallest of the buffer size or our data size - how much we've already sent
            const size_t cpamount = size - cur_idx >= alen - _write_idx ? alen - _write_idx : size - cur_idx;
            memcpy(br_buf + _write_idx, buf + cur_idx, cpamount);
            // increment write idx
            _write_idx += cpamount;
            // increment the buffer pointer
            cur_idx += cpamount;
            // if we filled the buffer, reset _write_idx, and mark the data for sending
            if (_write_idx == alen)
            {
                // indicate to bearssl that we are done writing
                br_ssl_engine_sendapp_ack(_eng, _write_idx);
                // reset the write index
                _write_idx = 0;
                // write to the socket immediatly
                if (mRunUntil(BR_SSL_SENDAPP) < 0)
                {
#if defined(ENABLE_DEBUG)
                    esp_ssl_debug_print(PSTR("Failed while waiting for the engine to enter BR_SSL_SENDAPP."), _debug_level, esp_ssl_debug_error, func_name);
#endif
                    return 0;
                }
                // reset the buffer pointer
                br_buf = br_ssl_engine_sendapp_buf(_eng, &alen);
            }
        }
        // works oky
        return size;
    }

    size_t write(uint8_t b) override { return write(&b, 1); }

    size_t write_P(PGM_P buf, size_t size)
    {
        char dest[size];
        memcpy_P(reinterpret_cast<void *>(dest), buf, size);
        return write(reinterpret_cast<const uint8_t *>(dest), size);
    }

    size_t write(Stream &stream)
    {
        if (!mIsClientInitialized(false))
            return 0;

        if (!connected())
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Connect not completed yet."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return 0;
        }

        size_t dl = stream.available();
        uint8_t buf[dl];
        stream.readBytes(buf, dl);
        return write(buf, dl);
    }

    int peek() override
    {

        if ((_secure) || !available())
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Not connected, none left available."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return -1;
        }

        if (!_secure)
            return _basic_client->peek();

        _recvapp_buf = br_ssl_engine_recvapp_buf(_eng, &_recvapp_len);
        if (_recvapp_buf && _recvapp_len)
            return _recvapp_buf[0];

#if defined(ENABLE_DEBUG)
        esp_ssl_debug_print(PSTR("No data left."), _debug_level, esp_ssl_debug_error, __func__);
#endif
        return -1;
    }

    size_t peekBytes(uint8_t *buffer, size_t length)
    {
        if (!mIsClientInitialized(false) || !_secure)
            return 0;

        size_t to_copy = 0;

        unsigned long _startMillis = millis();
        while ((available() < (int)length) && ((millis() - _startMillis) < 5000))
        {
            yield();
        }

        to_copy = _recvapp_len < length ? _recvapp_len : length;
        memcpy(buffer, _recvapp_buf, to_copy);
        return to_copy;
    }

    void setInsecure()
    {
        mClearAuthenticationSettings();
        _use_insecure = true;
    }

    void enableSSL(bool enable) { _isSSLEnabled = enable; }

    int connectSSL(IPAddress ip, uint16_t port)
    {

        if (!mIsClientInitialized(true))
            return 0;

        if (!_basic_client->connected() && !mConnectBasicClient(nullptr, ip, port))
            return 0;

        _ip = ip;
        _port = port;
        _connect_with_ip = true;

        return mConnectSSL(nullptr);
    }

    int connectSSL(const char *host, uint16_t port)
    {
        if (!mIsClientInitialized(true))
            return 0;

        if (!_basic_client->connected() && !mConnectBasicClient(host, IPAddress(), port))
            return 0;

        if (host != _host)
        {
            // Only copy if the pointers are different
            strncpy(_host, host, sizeof(_host) - 1);
            _host[sizeof(_host) - 1] = '\0';
        }

        _port = port;
        _connect_with_ip = false;

        return mConnectSSL(host);
    }

    void stop() override
    {
        if (!_secure)
            return;

        // Only if we've already connected, store session params and clear the connection options
        if (_session)
            br_ssl_engine_get_session_parameters(_eng, _session->getSession());

        // tell the SSL connection to gracefully close
        // Disabled to prevent close_notify from hanging BSSL_SSLClient
        // br_ssl_engine_close(_eng);
        // if the engine isn't closed, and the socket is still open
        auto state = br_ssl_engine_current_state(_eng);
        if (state != BR_SSL_CLOSED && state != 0 && connected())
        {
            // Discard any incoming application data.
            _recvapp_buf = br_ssl_engine_recvapp_buf(_eng, &_recvapp_len);
            if (_recvapp_buf != nullptr)
                br_ssl_engine_recvapp_ack(_eng, _recvapp_len);
            // run SSL to finish any existing transactions
            flush();
        }

        // close the socket
        if (_basic_client)
        {
            _basic_client->flush();
            _basic_client->stop();
        }

        mFreeSSL();
    }

    void setTimeout(unsigned long timeoutMs) { _timeout_ms = timeoutMs; }

    void setHandshakeTimeout(unsigned long timeoutMs) { _handshake_timeout = timeoutMs; }

    void setSessionTimeout(uint32_t seconds) { _tcp_session_timeout = seconds; }

    void flush() override
    {
        if (!_secure && _basic_client)
        {
            _basic_client->flush();
            return;
        }

        if (_write_idx > 0)
        {
            if (mRunUntil(BR_SSL_RECVAPP) < 0)
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("Could not flush write buffer!"), _debug_level, esp_ssl_debug_error, __func__);
                int error = br_ssl_engine_last_error(_eng);
                if (error != BR_ERR_OK)
                    mPrintSSLError(error, esp_ssl_debug_error, __func__);
                if (getWriteError())
                    mPrintClientError(getWriteError(), esp_ssl_debug_error, __func__);
#endif
            }
        }
    }

    void setBufferSizes(int recv, int xmit)
    {
        // Following constants taken from bearssl/src/ssl/ssl_engine.c (not exported unfortunately)
        const int MAX_OUT_OVERHEAD = 85;
        const int MAX_IN_OVERHEAD = 325;

        // The data buffers must be between 512B and 16KB

#if !defined(STATIC_IN_BUFFER_SIZE)
        recv = (recv < 512) ? 512 : ((recv > 16384) ? 16384 : recv);
#else
        recv = (STATIC_IN_BUFFER_SIZE < 512) ? 512 : ((STATIC_IN_BUFFER_SIZE > 16384) ? 16384 : STATIC_IN_BUFFER_SIZE);
#endif
#if !defined(STATIC_OUT_BUFFER_SIZE)
        xmit = (xmit < 512) ? 512 : ((xmit > 16384) ? 16384 : xmit);
#else
        xmit = (STATIC_OUT_BUFFER_SIZE < 512) ? 512 : ((STATIC_OUT_BUFFER_SIZE > 16384) ? 16384 : STATIC_OUT_BUFFER_SIZE);
#endif

        // Add in overhead for SSL protocol
        recv += MAX_IN_OVERHEAD;
        xmit += MAX_OUT_OVERHEAD;

        _iobuf_in_size = recv;
        _iobuf_out_size = xmit;
    }

    operator bool() override { return connected() > 0; }

    int availableForWrite() override
    {
        if (!mIsClientInitialized(false) || !_secure)
            return 0;

        // code taken from ::write()
        if (!connected() || !_handshake_done)
        {
            return 0;
        }
        // Get BearSSL to a state where we can send
        if (mRunUntil(BR_SSL_SENDAPP) < 0)
        {
            return 0;
        }
        if (br_ssl_engine_current_state(_eng) & BR_SSL_SENDAPP)
        {
            size_t sendapp_len;
            (void)br_ssl_engine_sendapp_buf(_eng, &sendapp_len);
            // We want to call br_ssl_engine_sendapp_ack(0) but 0 is forbidden (bssl doc).
            // After checking br_ssl_engine_sendapp_buf() src code,
            // it seems that it is OK to not call ack when the buffer is left untouched.
            // forbidden: br_ssl_engine_sendapp_ack(_eng, 0);
            return (int)sendapp_len;
        }
        return 0;
    }

    void setSession(BearSSL_Session *session) { _session = session; };

    void setX509Time(uint32_t now) { _now = now; }

#if !defined(SSLCLIENT_INSECURE_ONLY)
    void setKnownKey(const PublicKey *pk, unsigned usages = BR_KEYTYPE_KEYX | BR_KEYTYPE_SIGN)
    {
        mClearAuthenticationSettings();
        _knownkey = pk;
        _knownkey_usages = usages;
    }

    bool setFingerprint(const uint8_t fingerprint[20])
    {
        mClearAuthenticationSettings();
        _use_fingerprint = true;
        memcpy_P(_fingerprint, fingerprint, 20);
        return true;
    }

    bool setFingerprint(const char *fpStr)
    {
        int idx = 0;
        uint8_t c, d;
        uint8_t fp[20];

        while (idx < 20)
        {
            c = pgm_read_byte(fpStr++);
            if (!c)
            {
                break; // String ended, done processing
            }
            d = pgm_read_byte(fpStr++);
            if (!d)
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("FP too short"), _debug_level, esp_ssl_debug_error, __func__);
#endif
                return false; // Only half of the last hex digit, error
            }
            c = htoi(c);
            d = htoi(d);
            if ((c > 15) || (d > 15))
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("Invalid char"), _debug_level, esp_ssl_debug_error, __func__);
#endif
                return false; // Error in one of the hex characters
            }
            fp[idx++] = (c << 4) | d;

            // Skip 0 or more spaces or colons
            while (pgm_read_byte(fpStr) && (pgm_read_byte(fpStr) == ' ' || pgm_read_byte(fpStr) == ':'))
            {
                fpStr++;
            }
        }
        if ((idx != 20) || pgm_read_byte(fpStr))
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Garbage at end of fp"), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return false; // Garbage at EOL or we didn't have enough hex digits
        }
        return setFingerprint(fp);
    }

    void allowSelfSignedCerts()
    {
        mClearAuthenticationSettings();
        _use_self_signed = true;
    }

    void setTrustAnchors(const X509List *ta)
    {
        mClearAuthenticationSettings();
        mClearInternalTA();
        _ta = ta;
    }

    void setClientRSACert(const X509List *chain, const PrivateKey *sk)
    {
        mClearInternalChain();
        mClearInternalSK();
        _chain = chain;
        _sk = sk;
    }

    void setClientECCert(const X509List *chain, const PrivateKey *sk, unsigned int allowed_usages, unsigned int cert_issuer_key_type)
    {
        mClearInternalChain();
        mClearInternalSK();
        _chain = chain;
        _sk = sk;
        _allowed_usages = allowed_usages;
        _cert_issuer_key_type = cert_issuer_key_type;
    }
#endif

    int getMFLNStatus() { return connected() && br_ssl_engine_get_mfln_negotiated(_eng); }

    int getLastSSLError(char *dest, size_t len)
    {
        int err = 0;
        int error_code_for_lookup = 0; // New variable to isolate the base error for the switch

        err = br_ssl_engine_last_error(_eng);

        // 1. Determine the effective error code for lookup
        if (_oom_err)
        {
            err = -1000;
            error_code_for_lookup = -1000;
        }
        else
        {
            error_code_for_lookup = err;

            // Clear alert flags from the lookup value, but preserve them in 'err' (the return value)
            if (error_code_for_lookup & BR_ERR_RECV_FATAL_ALERT)
            {
                error_code_for_lookup &= ~BR_ERR_RECV_FATAL_ALERT;
            }
            if (error_code_for_lookup & BR_ERR_SEND_FATAL_ALERT)
            {
                error_code_for_lookup &= ~BR_ERR_SEND_FATAL_ALERT;
            }
        }

#if defined(ENABLE_ERROR_STRING)
        // 2. Determine prefix strings and main error string
        const char *recv_fatal = "";
        const char *send_fatal = "";

        // Check the original 'err' for alert flags for the prefix
        if (err & BR_ERR_RECV_FATAL_ALERT)
        {
            recv_fatal = PSTR("SSL received fatal alert - ");
        }
        if (err & BR_ERR_SEND_FATAL_ALERT)
        {
            send_fatal = PSTR("SSL sent fatal alert - ");
        }

        const char *t = get_br_error_string(error_code_for_lookup); // Call the new static helper

        // 3. Format output string
        if (dest)
        {
            // snprintf is PSTR safe and guaranteed to 0-terminate
            snprintf(dest, len, "%s%s%s", recv_fatal, send_fatal, t);
        }
#else
        (void)dest;
        (void)len;
#endif

        return err; // Return the full error code including alert flags
    }

#if defined(ENABLE_FS)
    void setCertStore(CertStoreBase *certStore) { _certStore = certStore; }
#endif
    bool setCiphers(const uint16_t *cipherAry, int cipherCount)
    {
        _cipher_list = reinterpret_cast<uint16_t *>(esp_sslclient_malloc(cipherCount));
        if (!_cipher_list)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("list empty"), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return false;
        }
        memcpy_P(_cipher_list, cipherAry, cipherCount * sizeof(uint16_t));
        _cipher_cnt = cipherCount;
        return true;
    }

#if !defined(__AVR__)
    bool setCiphers(const Vector<uint16_t> &list) { return setCiphers(&list[0], list.size()); }
#endif

    bool setCiphersLessSecure() { return setCiphers(faster_suites_P, sizeof(faster_suites_P) / sizeof(faster_suites_P[0])); }

    bool setSSLVersion(uint32_t min, uint32_t max)
    {
        if (((min != BR_TLS10) && (min != BR_TLS11) && (min != BR_TLS12)) ||
            ((max != BR_TLS10) && (max != BR_TLS11) && (max != BR_TLS12)) ||
            (max < min))
        {
            return false; // Invalid options
        }
        _tls_min = min;
        _tls_max = max;
        return true;
    }

    bool probeMaxFragmentLength(IPAddress ip, uint16_t port, uint16_t len) { return mProbeMaxFragmentLength(nullptr, ip, port, len); }

    bool probeMaxFragmentLength(const char *host, uint16_t port, uint16_t len) { return BSSL_SSLClient::probeMaxFragmentLength(host, port, len); }

    size_t peekAvailable() EMBED_SSL_ENGINE_BASE_OVERRIDE { return available(); }

    const char *peekBuffer() EMBED_SSL_ENGINE_BASE_OVERRIDE { return (const char *)_recvapp_buf; }

    void peekConsume(size_t consume) EMBED_SSL_ENGINE_BASE_OVERRIDE
    {
        // according to BSSL_SSLClient::read:
        br_ssl_engine_recvapp_ack(_eng, consume);
        _recvapp_buf = nullptr;
        _recvapp_len = 0;
    }

#if !defined(SSLCLIENT_INSECURE_ONLY)
    void setCACert(const char *rootCA)
    {
        mClearAuthenticationSettings(false);
        mClearInternalTA();
        _ta = nullptr;
        _internal_ta = new X509List(rootCA);
    }

    void setCertificate(const char *client_ca)
    {
        mClearAuthenticationSettings(false);
        mClearInternalChain();
        _chain = nullptr;
        _internal_chain = new X509List(client_ca);
    }

    void setPrivateKey(const char *private_key)
    {
        mClearAuthenticationSettings(false);
        mClearInternalSK();
        _sk = nullptr;
        _internal_sk = new PrivateKey(private_key);
    }

    void setPrivateECKey(const char *private_key, unsigned int allowed_usages, unsigned int cert_issuer_key_type)
    {
        mClearAuthenticationSettings(false);
        mClearInternalSK();
        _sk = nullptr;
        _internal_sk = new PrivateKey(private_key);
        _allowed_usages = allowed_usages;
        _cert_issuer_key_type = cert_issuer_key_type;
    }

    bool loadCACert(Stream &stream, size_t size)
    {
        bool ret = false;
        auto buff = reinterpret_cast<char *>(esp_sslclient_malloc(size));
        if (size == stream.readBytes(buff, size))
        {
            setCACert(buff);
            ret = true;
        }
        esp_sslclient_free(&buff);
        return ret;
    }

    bool loadCertificate(Stream &stream, size_t size)
    {
        bool ret = false;
        auto buff = reinterpret_cast<char *>(esp_sslclient_malloc(size));
        if (size == stream.readBytes(buff, size))
        {
            setCertificate(buff);
            ret = true;
        }
        esp_sslclient_free(&buff);
        return ret;
    }

    bool loadPrivateKey(Stream &stream, size_t size)
    {
        bool ret = false;
        auto buff = reinterpret_cast<char *>(esp_sslclient_malloc(size));
        if (size == stream.readBytes(buff, size))
        {
            setPrivateKey(buff);
            ret = true;
        }
        esp_sslclient_free(&buff);
        return ret;
    }
#endif

    int connect(IPAddress ip, uint16_t port, const char *rootCABuff, const char *cli_cert, const char *cli_key)
    {
        setSecure(rootCABuff, cli_cert, cli_key);
        return connect(ip, port);
    }

    int connect(const char *host, uint16_t port, const char *rootCABuff, const char *cli_cert, const char *cli_key)
    {
        setSecure(rootCABuff, cli_cert, cli_key);
        return connect(host, port);
    }

    BSSL_SSLClient &operator=(const BSSL_SSLClient &other)
    {
        stop();
        setClient(other._basic_client);
        _use_insecure = other._use_insecure;
        _timeout_ms = other._timeout_ms;
        _handshake_timeout = other._handshake_timeout;
        _tcp_session_timeout = other._tcp_session_timeout;
        return *this;
    }

    bool operator==(const bool value) { return bool() == value; }

    bool operator!=(const bool value) { return bool() != value; }

    bool operator==(const BSSL_SSLClient &rhs) { return _basic_client == rhs._basic_client; }

    bool operator!=(const BSSL_SSLClient &rhs) { return !this->operator==(rhs); };

    unsigned int getTimeout() const { return _timeout_ms; }

    void setSecure(const char *rootCABuff, const char *cli_cert, const char *cli_key)
    {

        mClearAuthenticationSettings();
#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (rootCABuff)
        {
            setCertificate(rootCABuff);
        }
        if (cli_cert && cli_key)
        {
            setCertificate(cli_cert);
            setPrivateKey(cli_key);
        }
#endif
    }

    void clearAuthenticationSettings() { mClearAuthenticationSettings(); }

private:
#if defined(ENABLE_ERROR_STRING)
    /**
     * @brief Maps the base error code from BearSSL to a human-readable string.
     * @param err_code The BearSSL error code (without fatal alert flags).
     * @return const char* pointing to the PROGMEM string.
     */
    static const char *get_br_error_string(int err_code)
    {
        // This is a private helper, all strings use PSTR for PROGMEM.
        switch (err_code)
        {
        case -1000:
            return PSTR("Unable to allocate memory for SSL structures and buffers.");
        case BR_ERR_BAD_PARAM:
            return PSTR("Caller-provided parameter is incorrect.");
        case BR_ERR_BAD_STATE:
            return PSTR("Operation requested by the caller cannot be applied with the current context state.");
        case BR_ERR_UNSUPPORTED_VERSION:
            return PSTR("Incoming protocol or record version is unsupported.");
        case BR_ERR_BAD_VERSION:
            return PSTR("Incoming record version does not match the expected version.");
        case BR_ERR_BAD_LENGTH:
            return PSTR("Incoming record length is invalid.");
        case BR_ERR_TOO_LARGE:
            return PSTR("Incoming record is too large or buffer is too small.");
        case BR_ERR_BAD_MAC:
            return PSTR("Decryption found an invalid padding, or the record MAC is not correct.");
        case BR_ERR_NO_RANDOM:
            return PSTR("No initial entropy was provided.");
        case BR_ERR_UNKNOWN_TYPE:
            return PSTR("Incoming record type is unknown.");
        case BR_ERR_UNEXPECTED:
            return PSTR("Incoming record or message has wrong type.");
        case BR_ERR_BAD_CCS:
            return PSTR("ChangeCipherSpec message from the peer has invalid contents.");
        case BR_ERR_BAD_ALERT:
            return PSTR("Alert message from the peer has invalid contents.");
        case BR_ERR_BAD_HANDSHAKE:
            return PSTR("Incoming handshake message decoding failed.");
        case BR_ERR_OVERSIZED_ID:
            return PSTR("ServerHello contains a session ID larger than 32 bytes.");
        case BR_ERR_BAD_CIPHER_SUITE:
            return PSTR("Server wants to use an unsupported cipher suite.");
        case BR_ERR_BAD_COMPRESSION:
            return PSTR("Server wants to use an unsupported compression.");
        case BR_ERR_BAD_FRAGLEN:
            return PSTR("Server's max fragment length does not match client's.");
        case BR_ERR_BAD_SECRENEG:
            return PSTR("Secure renegotiation failed.");
        case BR_ERR_EXTRA_EXTENSION:
            return PSTR("Server sent an unexpected or duplicate extension type.");
        case BR_ERR_BAD_SNI:
            return PSTR("Invalid Server Name Indication contents.");
        case BR_ERR_BAD_HELLO_DONE:
            return PSTR("Invalid ServerHelloDone from the server (length is not 0).");
        case BR_ERR_LIMIT_EXCEEDED:
            return PSTR("Internal limit exceeded (e.g. server's public key is too large).");
        case BR_ERR_BAD_FINISHED:
            return PSTR("Finished message from peer does not match the expected value.");
        case BR_ERR_RESUME_MISMATCH:
            return PSTR("Session resumption attempt with distinct version or cipher suite.");
        case BR_ERR_INVALID_ALGORITHM:
            return PSTR("Unsupported or invalid algorithm.");
        case BR_ERR_BAD_SIGNATURE:
            return PSTR("Invalid signature in ServerKeyExchange or CertificateVerify message.");
        case BR_ERR_WRONG_KEY_USAGE:
            return PSTR("Peer's public key does not have the proper type/usage.");
        case BR_ERR_NO_CLIENT_AUTH:
            return PSTR("Client did not send a certificate upon request, or the certificate could not be validated.");
        case BR_ERR_IO:
            return PSTR("I/O error or premature close on transport stream.");
        case BR_ERR_X509_INVALID_VALUE:
            return PSTR("Invalid value in an ASN.1 structure.");
        case BR_ERR_X509_TRUNCATED:
            return PSTR("Truncated certificate or other ASN.1 object.");
        case BR_ERR_X509_EMPTY_CHAIN:
            return PSTR("Empty certificate chain (no certificate at all).");
        case BR_ERR_X509_INNER_TRUNC:
            return PSTR("Decoding error: inner element extends beyond outer element size.");
        case BR_ERR_X509_BAD_TAG_CLASS:
            return PSTR("Decoding error: unsupported tag class.");
        case BR_ERR_X509_BAD_TAG_VALUE:
            return PSTR("Decoding error: unsupported tag value.");
        case BR_ERR_X509_INDEFINITE_LENGTH:
            return PSTR("Decoding error: indefinite length.");
        case BR_ERR_X509_EXTRA_ELEMENT:
            return PSTR("Decoding error: extraneous element.");
        case BR_ERR_X509_UNEXPECTED:
            return PSTR("Decoding error: unexpected element.");
        case BR_ERR_X509_NOT_CONSTRUCTED:
            return PSTR("Decoding error: expected constructed element, but is primitive.");
        case BR_ERR_X509_NOT_PRIMITIVE:
            return PSTR("Decoding error: expected primitive element, but is constructed.");
        case BR_ERR_X509_PARTIAL_BYTE:
            return PSTR("Decoding error: BIT STRING length is not multiple of 8.");
        case BR_ERR_X509_BAD_BOOLEAN:
            return PSTR("Decoding error: BOOLEAN value has invalid length.");
        case BR_ERR_X509_OVERFLOW:
            return PSTR("Decoding error: value is off-limits.");
        case BR_ERR_X509_BAD_DN:
            return PSTR("Invalid distinguished name.");
        case BR_ERR_X509_BAD_TIME:
            return PSTR("Invalid date/time representation.");
        case BR_ERR_X509_UNSUPPORTED:
            return PSTR("Certificate contains unsupported features that cannot be ignored.");
        case BR_ERR_X509_LIMIT_EXCEEDED:
            return PSTR("Key or signature size exceeds internal limits.");
        case BR_ERR_X509_WRONG_KEY_TYPE:
            return PSTR("Key type does not match that which was expected.");
        case BR_ERR_X509_BAD_SIGNATURE:
            return PSTR("Signature is invalid.");
        case BR_ERR_X509_TIME_UNKNOWN:
            return PSTR("Validation time is unknown.");
        case BR_ERR_X509_EXPIRED:
            return PSTR("Certificate is expired or not yet valid.");
        case BR_ERR_X509_DN_MISMATCH:
            return PSTR("Issuer/Subject DN mismatch in the chain.");
        case BR_ERR_X509_BAD_SERVER_NAME:
            return PSTR("Expected server name was not found in the chain.");
        case BR_ERR_X509_CRITICAL_EXTENSION:
            return PSTR("Unknown critical extension in certificate.");
        case BR_ERR_X509_NOT_CA:
            return PSTR("Not a CA, or path length constraint violation.");
        case BR_ERR_X509_FORBIDDEN_KEY_USAGE:
            return PSTR("Key Usage extension prohibits intended usage.");
        case BR_ERR_X509_WEAK_PUBLIC_KEY:
            return PSTR("Public key found in certificate is too small.");
        case BR_ERR_X509_NOT_TRUSTED:
            return PSTR("Chain could not be linked to a trust anchor.");
        default:
            return PSTR("Unknown error code.");
        }
    }
#endif

    // Checks for support of Maximum Frame Length Negotiation at the given
    // blocksize.  Note that, per spec, only 512, 1024, 2048, and 4096 are
    // supported.  Many servers today do not support this negotiation.

    // TODO - Allow for fragmentation...but not very critical as the ServerHello
    //      we use comes to < 80 bytes which has no reason to ever be fragmented.
    // TODO - Check the type of returned extensions and that the MFL is the exact
    //      same one we sent.  Not critical as only horribly broken servers would
    //      return changed or add their own extensions.
    bool mProbeMaxFragmentLength(Client *probe, uint16_t len)
    {

        // Hardcoded TLS 1.2 packets used throughout
        static const uint8_t clientHelloHead_P[] CONST_IN_FLASH = {
            0x16,
            0x03,
            0x03,
            0x00,
            0, // TLS header, change last 2 bytes to len
            0x01,
            0x00,
            0x00,
            0, // Last 3 bytes == length
            0x03,
            0x03, // Proto version TLS 1.2
            0x01,
            0x02,
            0x03,
            0x04,
            0x05,
            0x06,
            0x07,
            0x08, // Random (gmtime + rand[28])
            0x11,
            0x12,
            0x13,
            0x14,
            0x15,
            0x16,
            0x17,
            0x18,
            0x01,
            0x02,
            0x03,
            0x04,
            0x05,
            0x06,
            0x07,
            0x08,
            0x11,
            0x12,
            0x13,
            0x14,
            0x15,
            0x16,
            0x17,
            0x18,
            0x00, // Session ID
        };
        // Followed by our cipher-suite, generated on-the-fly
        //    0x00, 0x02, // cipher suite len
        //      0xc0, 0x13, // BR_TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA
        static const uint8_t clientHelloTail_P[] CONST_IN_FLASH = {
            0x01,
            0x00, // No compression
            0x00,
            26 + 14 + 6 + 5, // Extension length
            0x00,
            0x0d,
            0x00,
            0x16,
            0x00,
            0x14,
            0x04,
            0x03,
            0x03,
            0x03,
            0x05,
            0x03,
            0x06,
            0x03,
            0x02,
            0x03,
            0x04,
            0x01,
            0x03,
            0x01,
            0x05,
            0x01,
            0x06,
            0x01,
            0x02,
            0x01, // Supported signature algorithms
            0x00,
            0x0a,
            0x00,
            0x0a,
            0x00,
            0x08,
            0x00,
            0x17,
            0x00,
            0x18,
            0x00,
            0x19,
            0x00,
            0x1d, // Supported groups
            0x00,
            0x0b,
            0x00,
            0x02,
            0x01,
            0x00, // Supported EC formats
            0x00,
            0x01, // Max Frag Len
            0x00,
            0x01, // len of MaxFragLen
        };
        // Followed by a 1-byte MFLN size requesst
        //          0x04 // 2^12 = 4K
        uint8_t mfl;

        switch (len)
        {
        case 512:
            mfl = 1;
            break;
        case 1024:
            mfl = 2;
            break;
        case 2048:
            mfl = 3;
            break;
        case 4096:
            mfl = 4;
            break;
        default:
            return false; // Invalid size
        }
        int ttlLen = sizeof(clientHelloHead_P) + (2 + sizeof(suites_P)) + (sizeof(clientHelloTail_P) + 1);
        uint8_t *clientHello = reinterpret_cast<uint8_t *>(esp_sslclient_malloc(ttlLen));
        if (!clientHello)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("OOM error."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return false;
        }
        memcpy_P(clientHello, clientHelloHead_P, sizeof(clientHelloHead_P));
        clientHello[sizeof(clientHelloHead_P) + 0] = sizeof(suites_P) >> 8;   // MSB byte len
        clientHello[sizeof(clientHelloHead_P) + 1] = sizeof(suites_P) & 0xff; // LSB byte len
        for (size_t i = 0; i < sizeof(suites_P) / sizeof(suites_P[0]); i++)
        {
            uint16_t flip = pgm_read_word(&suites_P[i]);
            // Swap to network byte order
            flip = ((flip >> 8) & 0xff) | ((flip & 0xff) << 8);
            memcpy(clientHello + sizeof(clientHelloHead_P) + 2 + 2 * i, &flip, 2);
        }
        memcpy_P(clientHello + sizeof(clientHelloHead_P) + 2 + sizeof(suites_P), clientHelloTail_P, sizeof(clientHelloTail_P));
        clientHello[sizeof(clientHelloHead_P) + 2 + sizeof(suites_P) + sizeof(clientHelloTail_P)] = mfl;

        // Fix up TLS fragment length
        clientHello[3] = (ttlLen - 5) >> 8;
        clientHello[4] = (ttlLen - 5) & 0xff;
        // Fix up ClientHello message length
        clientHello[7] = (ttlLen - 5 - 4) >> 8;
        clientHello[8] = (ttlLen - 5 - 4) & 0xff;

        int ret = probe->write(clientHello, ttlLen);
        esp_sslclient_free(&clientHello); // We're done w/the hello message
        if (!probe->connected() || (ret != ttlLen))
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Protocol error."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return false;
        }

        bool supportsLen = false;
        uint8_t fragResp[5];
        int fragLen;
        uint8_t hand[4];
        int handLen;
        uint8_t protoVer[2];
        uint8_t rand[32];
        uint8_t sessionLen;
        uint8_t cipher[2];
        uint8_t comp;
        uint8_t extBytes[2];
        uint16_t extLen;

        ret = probe->readBytes(fragResp, 5);
        if (!probe->connected() || (ret != 5) || (fragResp[0] != 0x16) || (fragResp[1] != 0x03) || (fragResp[2] != 0x03))
        {
            // Short read, not a HANDSHAKE or not TLS 1.2, so it's not supported
            return send_abort(probe, supportsLen);
        }
        fragLen = (fragResp[3] << 8) | fragResp[4];
        if (fragLen < 4 + 2 + 32 + 1 + 2 + 1)
        {
            // Too short to have an extension
            return send_abort(probe, supportsLen);
        }

        ret = probe->readBytes(hand, 4);
        fragLen -= ret;
        if ((ret != 4) || (hand[0] != 2))
        {
            // Short read or not server_hello
            return send_abort(probe, supportsLen);
        }
        handLen = (hand[1] << 16) | (hand[2] << 8) | hand[3];
        if (handLen != fragLen)
        {
            // Got some weird mismatch, this is invalid
            return send_abort(probe, supportsLen);
        }

        ret = probe->readBytes(protoVer, 2);
        handLen -= ret;
        if ((ret != 2) || (protoVer[0] != 0x03) || (protoVer[1] != 0x03))
        {
            // Short read or not tls 1.2, so can't do MFLN
            return send_abort(probe, supportsLen);
        }

        ret = probe->readBytes(rand, 32);
        handLen -= ret;
        if (ret != 32)
        {
            // short read of random data
            return send_abort(probe, supportsLen);
        }

        ret = probe->readBytes(&sessionLen, 1);
        handLen -= ret;
        if ((ret != 1) || (sessionLen > 32))
        {
            // short read of session len or invalid size
            return send_abort(probe, supportsLen);
        }
        if (sessionLen)
        {
            ret = probe->readBytes(rand, sessionLen);
            handLen -= ret;
            if (ret != sessionLen)
            {
                // short session id read
                return send_abort(probe, supportsLen);
            }
        }

        ret = probe->readBytes(cipher, 2);
        handLen -= ret;
        if (ret != 2)
        {
            // Short read...we don't check the cipher here
            return send_abort(probe, supportsLen);
        }

        ret = probe->readBytes(&comp, 1);
        handLen -= ret;
        if ((ret != 1) || comp != 0)
        {
            // short read or invalid compression
            return send_abort(probe, supportsLen);
        }

        ret = probe->readBytes(extBytes, 2);
        handLen -= ret;
        extLen = extBytes[1] | (extBytes[0] << 8);
        if ((extLen == 0) || (ret != 2))
        {
            return send_abort(probe, supportsLen);
        }

        while (handLen > 0)
        {
            // Parse each extension and look for MFLN
            uint8_t typeBytes[2];
            ret = probe->readBytes(typeBytes, 2);
            handLen -= 2;
            if ((ret != 2) || (handLen <= 0))
            {
                return send_abort(probe, supportsLen);
            }
            uint8_t lenBytes[2];
            ret = probe->readBytes(lenBytes, 2);
            handLen -= 2;
            uint16_t _extLen = lenBytes[1] | (lenBytes[0] << 8);
            if ((ret != 2) || (handLen <= 0) || (_extLen > 32) || ((int)_extLen > handLen))
            {
                return send_abort(probe, supportsLen);
            }
            if ((typeBytes[0] == 0x00) && (typeBytes[1] == 0x01))
            { // MFLN extension!
                // If present and 1-byte in length, it's supported
                return send_abort(probe, _extLen == 1 ? true : false);
            }
            // Skip the extension, move to next one
            uint8_t junk[32];
            ret = probe->readBytes(junk, _extLen);
            handLen -= _extLen;
            if (ret != (int)_extLen)
            {
                return send_abort(probe, supportsLen);
            }
        }
        return send_abort(probe, supportsLen);
    }

    bool mProbeMaxFragmentLength(const char *name, IPAddress ip, uint16_t port, uint16_t len)
    {
        if (!mIsClientInitialized(false))
            return false;

        _basic_client->stop();

        if (!(name ? _basic_client->connect(name, port) : _basic_client->connect(ip, port)))
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Can't connect."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return false;
        }

        bool ret = mProbeMaxFragmentLength(_basic_client, len);
        _basic_client->stop();
        return ret;
    }

    int mIsClientInitialized(bool notify)
    {
        if (!_basic_client)
        {
#if defined(ENABLE_DEBUG)
            if (notify)
                esp_ssl_debug_print(PSTR("Basic client is not yet initialized."), _debug_level, esp_ssl_debug_error, __func__);
#else
            (void)notify;
#endif
            return 0;
        }
        return 1;
    }

    int mConnectBasicClient(const char *host, IPAddress ip, uint16_t port)
    {

        if (!mConnectionValidate(host, ip, port))
            return 0;

        if (!(host ? _basic_client->connect(host, port) : _basic_client->connect(ip, port)))
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Failed to connect to server using basic client."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            setWriteError(esp_ssl_connection_fail);
            mFreeSSL();
            return 0;
        }

        _secure = false;
        _write_idx = 0;
#if defined(ENABLE_DEBUG)
        esp_ssl_debug_print(PSTR("Basic client connected!"), _debug_level, esp_ssl_debug_info, __func__);
#endif
        return 1;
    }
    // Returns whether or not the engine is connected, without polling the client over SPI or other (as opposed to connected())
    bool mSoftConnected(const char *func_name)
    {
        // check if the socket is still open and such
        if (getWriteError())
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Cannot operate if the write error is not reset."), _debug_level, esp_ssl_debug_error, func_name);
            mPrintClientError(getWriteError(), esp_ssl_debug_error, func_name);
#else
            (void)func_name;
#endif
            return false;
        }
        // check if the ssl engine is still open
        if (!_is_connected || br_ssl_engine_current_state(_eng) == BR_SSL_CLOSED)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Cannot operate on a closed SSL connection."), _debug_level, esp_ssl_debug_error, func_name);
            int error = br_ssl_engine_last_error(_eng);
            if (error != BR_ERR_OK)
                mPrintSSLError(error, esp_ssl_debug_error, func_name);
#endif
            return false;
        }
        return true;
    }

    int mConnectSSL(const char *host = nullptr)
    {

#if defined(ENABLE_DEBUG)
        esp_ssl_debug_print(PSTR("Start connection."), _debug_level, esp_ssl_debug_info, __func__);
#endif
        mFreeSSL();
        _oom_err = false;

#if defined(ENABLE_DEBUG) && !defined(SSLCLIENT_INSECURE_ONLY)
        // BearSSL will reject all connections unless an authentication option is set, warn in DEBUG builds
#if defined(ENABLE_FS)
#define CRTSTORECOND &&!_certStore
#else
#define CRTSTORECOND
#endif
        if (!_use_insecure && !_use_fingerprint && !_use_self_signed && !_knownkey CRTSTORECOND && !_ta && !_internal_ta)
        {
            esp_ssl_debug_print(PSTR("Connection *will* fail, no authentication method is setup."), _debug_level, esp_ssl_debug_warn, __func__);
        }
#endif

#if defined(STATIC_SSLCLIENT_CONTEXT)
        br_ssl_client_context *sc_ptr = &_sc;

#else
        _sc = (br_ssl_client_context *)esp_sslclient_malloc(sizeof(br_ssl_client_context));
        br_ssl_client_context *sc_ptr = _sc;
#endif

#if !defined(STATIC_IN_BUFFER_SIZE)
        _iobuf_in = reinterpret_cast<unsigned char *>(esp_sslclient_malloc(_iobuf_in_size));
#endif
#if !defined(STATIC_OUT_BUFFER_SIZE) && !defined(SSLCLIENT_HALF_DUPLEX)
        _iobuf_out = reinterpret_cast<unsigned char *>(esp_sslclient_malloc(_iobuf_out_size));
#endif

#if (!defined(STATIC_IN_BUFFER_SIZE) || !defined(STATIC_OUT_BUFFER_SIZE) || !defined(STATIC_SSLCLIENT_CONTEXT))
#define NEED_OOM_CHECK
#endif

#if defined(NEED_OOM_CHECK)

        if (
#if !defined(STATIC_SSLCLIENT_CONTEXT)
            !sc_ptr

#if !defined(STATIC_IN_BUFFER_SIZE) || !defined(STATIC_OUT_BUFFER_SIZE)
            ||
#endif

#endif

#if !defined(STATIC_IN_BUFFER_SIZE)
            !_iobuf_in
#endif
#if !defined(STATIC_IN_BUFFER_SIZE) && !defined(STATIC_OUT_BUFFER_SIZE) && !defined(SSLCLIENT_HALF_DUPLEX)
            ||
#endif
#if !defined(STATIC_OUT_BUFFER_SIZE) && !defined(SSLCLIENT_HALF_DUPLEX)
            !_iobuf_out
#endif
        )
        {
            mFreeSSL();
            _oom_err = true;
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("OOM error."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return 0;
        }
#undef NEED_OOM_CHECK
#endif

        _eng = &sc_ptr->eng; // Allocation/deallocation taken care of by the _sc

        // If no cipher list yet set, use defaults
        if (!_cipher_list)
            bssl::br_ssl_client_base_init(sc_ptr, suites_P, sizeof(suites_P) / sizeof(suites_P[0]));
        else
            bssl::br_ssl_client_base_init(sc_ptr, _cipher_list, _cipher_cnt);

        // Only failure possible in the installation is OOM
        if (!mInstallClientX509Validator())
        {
            mFreeSSL();
            _oom_err = true;
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Can't install x509 validator."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return 0;
        }

#if defined(SSLCLIENT_HALF_DUPLEX)
        br_ssl_engine_set_buffer(_eng, _iobuf_in, _iobuf_in_size, 0);
#else
        br_ssl_engine_set_buffers_bidi(_eng, _iobuf_in, _iobuf_in_size, _iobuf_out, _iobuf_out_size);
#endif
        br_ssl_engine_set_versions(_eng, _tls_min, _tls_max);

#if !defined(SSLCLIENT_INSECURE_ONLY)
        // Apply any client certificates, if supplied.
        if ((_sk && _sk->isRSA()) || (_internal_sk && _internal_sk->isRSA()))
        {
            br_ssl_client_set_single_rsa(sc_ptr, _internal_chain ? _internal_chain->getX509Certs() : (_chain ? _chain->getX509Certs() : nullptr), _internal_chain ? _internal_chain->getCount() : (_chain ? _chain->getCount() : 0),
                                         _internal_sk ? _internal_sk->getRSA() : _sk->getRSA(), br_rsa_pkcs1_sign_get_default());
        }
        else if ((_sk && _sk->isEC()) || (_internal_sk && _internal_sk->isEC()))
        {
#ifndef BEARSSL_SSL_BASIC
            br_ssl_client_set_single_ec(sc_ptr, _internal_chain ? _internal_chain->getX509Certs() : (_chain ? _chain->getX509Certs() : nullptr), _internal_chain ? _internal_chain->getCount() : (_chain ? _chain->getCount() : 0),
                                        _internal_sk ? _internal_sk->getEC() : _sk->getEC(), _allowed_usages,
                                        _cert_issuer_key_type, br_ec_get_default(), br_ecdsa_sign_asn1_get_default());
#else
            mFreeSSL();
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Attempting to use EC cert in minimal cipher mode (no EC)."), _debug_level, esp_ssl_debug_error, __func__);
#endif
            return 0;
#endif
        }

#endif

        // clear the write error
        setWriteError(esp_ssl_ok);

        // we want 128 bits to be safe, as recommended by the bearssl docs
        uint8_t rng_seeds[16];

        // prng
        for (uint8_t i = 0; i < sizeof rng_seeds; i++)
            rng_seeds[i] = static_cast<uint8_t>(random(256));

        br_ssl_engine_inject_entropy(_eng, rng_seeds, sizeof rng_seeds);

        // Restore session from the storage spot, if present
        if (_session)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Set SSL session!"), _debug_level, esp_ssl_debug_info, __func__);
#endif
            br_ssl_engine_set_session_parameters(_eng, _session->getSession());
        }

        if (!br_ssl_client_reset(sc_ptr, host, _session ? 1 : 0))
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Can't reset client."), _debug_level, esp_ssl_debug_error, __func__);
            mPrintSSLError(br_ssl_engine_last_error(_eng), esp_ssl_debug_error, __func__);
#endif
            setWriteError(esp_ssl_connection_fail);
            mFreeSSL();
            return 0;
        }

// SSL/TLS handshake
#if defined(ENABLE_DEBUG)
        esp_ssl_debug_print(PSTR("Wait for SSL handshake."), _debug_level, esp_ssl_debug_info, __func__);
#endif

        if (mRunUntil(BR_SSL_SENDAPP, _handshake_timeout) < 0)
        {
#if defined(ENABLE_DEBUG)
            esp_ssl_debug_print(PSTR("Failed to initlalize the SSL layer."), _debug_level, esp_ssl_debug_error, __func__);
            mPrintSSLError(br_ssl_engine_last_error(_eng), esp_ssl_debug_error, __func__);
#endif
            mFreeSSL();
            return 0;
        }

#if defined(ENABLE_DEBUG)
        esp_ssl_debug_print(PSTR("Connection successful!"), _debug_level, esp_ssl_debug_info, __func__);
#endif
        _handshake_done = true;
        _is_connected = true;
        _secure = true;
        _session_ts = millis();

        // Save session
        if (_session)
            br_ssl_engine_get_session_parameters(_eng, _session->getSession());

// Session is already validated here, there is no need to keep following
#if !defined(STATIC_X509_CONTEXT)

#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (_x509_minimal)
            esp_sslclient_free((uint8_t **)&_x509_minimal);
        if (_x509_knownkey)
            esp_sslclient_free((uint8_t **)&_x509_knownkey);
#endif

        if (_x509_insecure)
            esp_sslclient_free((uint8_t **)&_x509_insecure);

#endif

        return 1;
    }

    static char custom_toupper(char c)
    {
        if (c >= 'a' && c <= 'z')
        {
            return c - ('a' - 'A');
        }
        return c;
    }

    int strcasecmp_custom(const char *s1, const char *s2)
    {
        const unsigned char *p1 = (const unsigned char *)s1;
        const unsigned char *p2 = (const unsigned char *)s2;
        unsigned char c1, c2;

        do
        {
            // 1. Convert characters to their uppercase equivalent
            c1 = custom_toupper(*p1++);
            c2 = custom_toupper(*p2++);

            // 2. If the characters differ, return the difference.
            if (c1 != c2)
            {
                return (int)c1 - (int)c2;
            }

            // 3. Stop if the null terminator is reached (meaning both strings match up to this point)
            if (c1 == '\0')
            {
                break;
            }

        } while (true);

        return 0; // Strings are identical (case-insensitive)
    }

    bool mConnectionValidate(const char *host, IPAddress ip, uint16_t port)
    {
        if (!mIsClientInitialized(true))
            return false;

        if (_basic_client && _basic_client->connected() &&
                    host
                ? (strcasecmp_custom(host, _host) != 0 || port != _port)
                : (ip != _ip || port != _port))
        {
            _basic_client->stop();
        }

        mCheckSessionTimeout();

        return true;
    }

    bool mCheckSessionTimeout()
    {

#if defined(ENABLE_DEBUG)
        const char *func_name = __func__;
#endif

        if (_tcp_session_timeout >= BSSL_SSL_CLIENT_MIN_SESSION_TIMEOUT_SEC && _session_ts > 0 && millis() - _session_ts > _tcp_session_timeout * 1000)
        {
            if (_basic_client && _basic_client->connected())
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("The session was timed out. Starting new server connection."), _debug_level, esp_ssl_debug_info, func_name);
#endif
                int ret = 0;
                if (!_secure)
                {
                    _basic_client->flush();
                    _basic_client->stop();

                    if (_connect_with_ip)
                        ret = connect(_ip, _port);
                    else
                        ret = connect(_host, _port);
                }
                else
                {
                    stop();
                    if (_connect_with_ip)
                        ret = connectSSL(_ip, _port);
                    else
                        ret = connectSSL(_host, _port);
                }

                if (!ret)
                {
#if defined(ENABLE_DEBUG)
                    esp_ssl_debug_print(PSTR("Failed while starting new server connection."), _debug_level, esp_ssl_debug_error, func_name);
#endif
                    return false;
                }
            }
        }

        return true;
    }

    int mRunUntil(const unsigned target, unsigned long timeout = 0)
    {
        unsigned lastState = 0;
        size_t lastLen = 0;
        const unsigned long start = millis();
        for (;;)
        {
            unsigned state = mUpdateEngine();
            // error check
            if (state == BR_SSL_CLOSED || getWriteError() != esp_ssl_ok)
            {
#if defined(ENABLE_DEBUG)
                if (state == BR_SSL_CLOSED)
                    esp_ssl_debug_print(PSTR("Terminating because the ssl engine closed."), _debug_level, esp_ssl_debug_warn, __func__);
                else
                    esp_ssl_debug_print(PSTR("Terminating with write error."), _debug_level, esp_ssl_debug_warn, __func__);
#endif
                return -1;
            }
            // timeout check
            if (millis() - start > ((timeout > 0) ? timeout : getTimeout()))
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("SSL internals timed out!"), _debug_level, esp_ssl_debug_error, __func__);
#endif
                setWriteError(esp_ssl_write_error);
                stop();
                return -1;
            }
            // debug
            if (state != lastState || lastState == 0)
            {
                lastState = state;
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("SSL state changed."), _debug_level, esp_ssl_debug_info, __func__);
                mPrintSSLState(state, esp_ssl_debug_info, __func__);
#endif
            }
            if (state & BR_SSL_RECVREC)
            {
                size_t len;
                br_ssl_engine_recvrec_buf(_eng, &len);
                if (lastLen != len)
                {
                    lastLen = len;
#if defined(ENABLE_DEBUG)
                    char s_buffer[64];
                    snprintf_P(s_buffer, sizeof(s_buffer), PSTR("Expected bytes count: %u"), (unsigned int)len);
                    esp_ssl_debug_print(s_buffer, _debug_level, esp_ssl_debug_info, __func__);
#endif
                }
            }
            /*
             * If we reached our target, then we are finished.
             */
            if (state & target || (target == 0 && state == 0))
                return 0;

            /*
             * If some application data must be read, and we did not
             * exit, then this means that we are trying to write data,
             * and that's not possible until the application data is
             * read. This may happen if using a shared in/out buffer,
             * and the underlying protocol is not strictly half-duplex.
             * Normally this would be unrecoverable, however we can attempt
             * to remedy the problem by telling the engine to discard
             * the data.
             */
            if (state & BR_SSL_RECVAPP)
            {
                _recvapp_buf = br_ssl_engine_recvapp_buf(_eng, &_recvapp_len);
                if (_recvapp_buf != nullptr)
                {
                    // if application data is ready in buffer, don't ignore, just return.

                    // _write_idx = 0;
                    // esp_ssl_debug_print(PSTR("Discarded unread data to favor a write operation."), _debug_level, esp_ssl_debug_warn, __func__);
                    // br_ssl_engine_recvapp_ack(_eng, len);
                    // continue;
                    return 0;
                }
                else
                {
#if defined(ENABLE_DEBUG)
                    esp_ssl_debug_print(PSTR("SSL engine state is RECVAPP, however the buffer was null! (This is a problem with BearSSL internals)."), _debug_level, esp_ssl_debug_error, __func__);
#endif
                    setWriteError(esp_ssl_write_error);
                    stop();
                    return -1;
                }
            }

            if (target & BR_SSL_SENDAPP)
            {
                // reset the write index
                _write_idx = 0;
                continue;
            }

            /*
             * We can reach that point if the target RECVAPP, and
             * the state contains SENDAPP only. This may happen with
             * a shared in/out buffer. In that case, we must flush
             * the buffered data to "make room" for a new incoming
             * record.
             */
            if (state & BR_SSL_SENDAPP && target & BR_SSL_RECVAPP)
                br_ssl_engine_flush(_eng, 0);
        }
    }

    unsigned mUpdateEngine()
    {
        for (;;)
        {
            // get the state
            unsigned state = br_ssl_engine_current_state(_eng);
            // debug
            if (_bssl_last_state == 0 || state != _bssl_last_state)
            {
                _bssl_last_state = state;
#if defined(ENABLE_DEBUG)
                mPrintSSLState(state, esp_ssl_debug_info, __func__);
#endif
            }
            if (state & BR_SSL_CLOSED)
                return state;
            /*
             * If there is some record data to send, do it. This takes
             * precedence over everything else.
             */
            if (state & BR_SSL_SENDREC)
            {
                unsigned char *buf;
                size_t len;
                int wlen;

                buf = br_ssl_engine_sendrec_buf(_eng, &len);
                wlen = _basic_client->write(buf, len);
                _basic_client->flush();
                if (wlen <= 0)
                {
                    // if the arduino client encountered an error
                    if (_basic_client->getWriteError() || !_basic_client->connected())
                    {
#if defined(ENABLE_DEBUG)
                        esp_ssl_debug_print(PSTR("Error writing to basic client."), _debug_level, esp_ssl_debug_error, __func__);
#endif
                        setWriteError(esp_ssl_write_error);
                    }
                    // else presumably the socket just closed itself, so just stop the engine
                    stop();
                    return 0;
                }
                if (wlen > 0)
                {
                    br_ssl_engine_sendrec_ack(_eng, wlen);
                }
                continue;
            }

            /*
             * If the client has specified there is client data to send, and
             * the engine is ready to handle it, send it along.
             */
            if (_write_idx > 0)
            {
                // if we've reached the point where BR_SSL_SENDAPP is off but
                // data has been written to the io buffer, something is wrong
                if (!(state & BR_SSL_SENDAPP))
                {
#if defined(ENABLE_DEBUG)
                    esp_ssl_debug_print(PSTR("Error _write_idx > 0 but the ssl engine is not ready for data."), _debug_level, esp_ssl_debug_error, __func__);
#endif
                    setWriteError(esp_ssl_write_error);
                    stop();
                    return 0;
                }
                // else time to send the application data
                else if (state & BR_SSL_SENDAPP)
                {
                    size_t alen;
                    const unsigned char *buf = br_ssl_engine_sendapp_buf(_eng, &alen);
                    // engine check
                    if (alen == 0 || buf == nullptr)
                    {
#if defined(ENABLE_DEBUG)
                        esp_ssl_debug_print(PSTR("Engine set write flag but returned null buffer."), _debug_level, esp_ssl_debug_error, __func__);
#endif
                        setWriteError(esp_ssl_write_error);
                        stop();
                        return 0;
                    }
                    // sanity check
                    if (alen < _write_idx)
                    {
#if defined(ENABLE_DEBUG)
                        esp_ssl_debug_print(PSTR("Alen is less than _write_idx."), _debug_level, esp_ssl_debug_error, __func__);
#endif
                        setWriteError(esp_ssl_internal_error);
                        stop();
                        return 0;
                    }
                    // all good? lets send the data
                    // presumably the BSSL_SSLClient::write function has already added
                    // data to *buf, so now we tell bearssl it's time for the
                    // encryption step.
                    // this will encrypt the data and presumably spit it out
                    // for BR_SSL_SENDREC to send over ethernet.
                    br_ssl_engine_sendapp_ack(_eng, _write_idx);
                    // reset the iobuffer index
                    _write_idx = 0;
                    // loop again!
                    continue;
                }
            }

            /*
             * If there is some record data to recieve, check if we've
             * recieved it so far. If we have, then we can update the state.
             * else we can return that we're still waiting for the server.
             */
            if (state & BR_SSL_RECVREC)
            {
                size_t len;
                unsigned char *buf = br_ssl_engine_recvrec_buf(_eng, &len);
                // do we have the record you're looking for?
                const auto avail = _basic_client->available();
                if (avail > 0)
                {
                    // I suppose so!
                    int rlen = _basic_client->read(buf, avail < (int)len ? avail : (int)len);
                    if (rlen <= 0)
                    {
#if defined(ENABLE_DEBUG)
                        char s_buffer[64];
                        snprintf_P(s_buffer, sizeof(s_buffer), PSTR("Error reading bytes from basic client. Write Error: %u"), (unsigned int)_basic_client->getWriteError());
                        esp_ssl_debug_print(s_buffer, _debug_level, esp_ssl_debug_error, __func__);
#endif
                        setWriteError(esp_ssl_write_error);
                        stop();
                        return 0;
                    }
                    if (rlen > 0)
                    {
                        br_ssl_engine_recvrec_ack(_eng, rlen);
                    }
                    continue;
                }
                // guess not, tell the state we're waiting still
                else
                {

#if defined __has_include
#if __has_include(<Ethernet.h>)
                    // Add a delay since spamming _basic_client->availible breaks the poor wiz chip
                    delay(10);
#endif
#endif
                    return state;
                }
            }
            // if it's not any of the above states, then it must be waiting to send or recieve app data
            // in which case we return
            return state;
        }
    }

#if defined(ENABLE_DEBUG)
    void mPrintClientError(const int ssl_error, int level, const char *func_name)
    {
        const char *msg = nullptr;

        switch (ssl_error)
        {
        case esp_ssl_ok:
            msg = PSTR("SSL OK");
            break;
        case esp_ssl_connection_fail:
            msg = PSTR("SSL Connection fail");
            break;
        case esp_ssl_write_error:
            msg = PSTR("SSL Write error");
            break;
        case esp_ssl_read_error:
            msg = PSTR("SSL Read error");
            break;
        case esp_ssl_out_of_memory:
            msg = PSTR("SSL OOM error");
            break;
        case esp_ssl_internal_error:
            msg = PSTR("SSL Internal error");
            break;
        }

        esp_ssl_debug_print(msg, _debug_level, level, func_name);
    }

    void mPrintSSLError(const unsigned br_error_code, int level, const char *func_name)
    {
        (void)br_error_code;
        char dest[300];
        getLastSSLError(dest, 300);
        esp_ssl_debug_print(dest, _debug_level, level, func_name);
    }

    void mPrintSSLState(const unsigned state, int level, const char *func_name)
    {
        const char *msg = nullptr;

        if (state == 0)
            msg = PSTR("State Invalid");
        else if (state & BR_SSL_CLOSED)
            msg = PSTR("State Connection close");
        else
        {
            if (state & BR_SSL_SENDREC)
                msg = PSTR("State SENDREC");
            if (state & BR_SSL_RECVREC)
                msg = PSTR("State RECVREC");
            if (state & BR_SSL_SENDAPP)
                msg = PSTR("State SENDAPP");
            if (state & BR_SSL_RECVAPP)
                msg = PSTR("State RECVAPP");
        }

        esp_ssl_debug_print(msg, _debug_level, level, func_name);
    }

#endif

#if !defined(__AVR__)
    bool mIsSecurePort(uint16_t port)
    {
        int size = 26;
        for (int i = 0; i < size; i++)
        {
            if (port == _secure_ports[i])
                return true;
        }

        return false;
    }
#endif
    void mBSSLX509InsecureInit(bssl::br_x509_insecure_context *ctx, int _use_fingerprint, const uint8_t _fingerprint[20], int _allow_self_signed)
    {
        static const br_x509_class br_x509_insecure_vtable CONST_IN_FLASH = {
            sizeof(bssl::br_x509_insecure_context),
            bssl::insecure_start_chain,
            bssl::insecure_start_cert,
            bssl::insecure_append,
            bssl::insecure_end_cert,
            bssl::insecure_end_chain,
            bssl::insecure_get_pkey};

        memset(ctx, 0, sizeof *ctx);
        ctx->vtable = &br_x509_insecure_vtable;
        ctx->done_cert = false;
        ctx->match_fingerprint = _use_fingerprint ? _fingerprint : nullptr;
        ctx->allow_self_signed = _allow_self_signed ? 1 : 0;
    }

    void mClearInternalTA()
    {
#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (_internal_ta)
        {
            delete _internal_ta;
            _internal_ta = nullptr;
        }
#endif
    }

    void mClearInternalChain()
    {
#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (_internal_chain)
        {
            delete _internal_chain;
            _internal_chain = nullptr;
        }
#endif
    }

    void mClearInternalSK()
    {
#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (_internal_sk)
        {
            delete _internal_sk;
            _internal_sk = nullptr;
        }
#endif
    }

    void mClearAuthenticationSettings(bool full_clear = true)
    {
        _use_insecure = false;
        _use_fingerprint = false;
        _use_self_signed = false;

#if !defined(SSLCLIENT_INSECURE_ONLY)
        _knownkey = nullptr;
        _ta = nullptr;
        if (full_clear)
        {
            mClearInternalTA();
            mClearInternalChain();
            mClearInternalSK();
        }
#endif
        esp_sslclient_free(&_cipher_list);
        _cipher_cnt = 0;
    }

    void mClear()
    {
        _timeout_ms = 15000;
#if !defined(STATIC_SSLCLIENT_CONTEXT)
        if (_sc)
            esp_sslclient_free((br_ssl_client_context **)&_sc);
#endif
        _eng = nullptr; // Alias pointer, clear only

#if !defined(STATIC_X509_CONTEXT)
        // Check and free dynamically allocated X509 contexts

#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (_x509_minimal)
            esp_sslclient_free((uint8_t **)&_x509_minimal);

        if (_x509_knownkey)
            esp_sslclient_free((uint8_t **)&_x509_knownkey);
#endif

        if (_x509_insecure)
            esp_sslclient_free((uint8_t **)&_x509_insecure);

#endif

#if !defined(STATIC_IN_BUFFER_SIZE)
        // Check and free dynamically allocated input buffer
        if (_iobuf_in)
            esp_sslclient_free((unsigned char **)&_iobuf_in);
#endif
#if !defined(STATIC_OUT_BUFFER_SIZE) && !defined(SSLCLIENT_HALF_DUPLEX)
        // Check and free dynamically allocated output buffer
        if (_iobuf_out)
            esp_sslclient_free((unsigned char **)&_iobuf_out);
#endif

        _now = 0;
#if !defined(SSLCLIENT_INSECURE_ONLY)
        _ta = nullptr;
#endif
        setBufferSizes(16384, 512);
        _secure = false;
        _recvapp_buf = nullptr;
        _recvapp_len = 0;
        _oom_err = false;
        _session = nullptr;
        _tls_min = BR_TLS10;
        _tls_max = BR_TLS12;
    }

    bool mInstallClientX509Validator()
    {
        if (_use_insecure || _use_fingerprint || _use_self_signed)
        {
#if !defined(STATIC_X509_CONTEXT)
            // Use common insecure x509 authenticator
            _x509_insecure = (bssl::br_x509_insecure_context *)esp_sslclient_malloc(sizeof(bssl::br_x509_insecure_context));
            if (!_x509_insecure)
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("OOM for _x509_insecure"), _debug_level, esp_ssl_debug_error, __func__);
#endif
                return false;
            }
#if !defined(SSLCLIENT_INSECURE_ONLY)
            mBSSLX509InsecureInit(_x509_insecure, _use_fingerprint, _fingerprint, _use_self_signed);
#else
            mBSSLX509InsecureInit(_x509_insecure, _use_fingerprint, nullptr, _use_self_signed);
#endif
            br_ssl_engine_set_x509(_eng, &_x509_insecure->vtable);
#else // STATIC_X509_CONTEXT
      // Use common insecure x509 authenticator
#if !defined(SSLCLIENT_INSECURE_ONLY)
            mBSSLX509InsecureInit(&_x509_insecure, _use_fingerprint, _fingerprint, _use_self_signed);
#else
            mBSSLX509InsecureInit(&_x509_insecure, _use_fingerprint, nullptr, _use_self_signed);
#endif
            br_ssl_engine_set_x509(_eng, &_x509_insecure.vtable);
#endif // STATIC_X509_CONTEXT
        }
#if !defined(SSLCLIENT_INSECURE_ONLY)
        else if (_knownkey)
        {

#if !defined(STATIC_X509_CONTEXT)
            // Simple, pre-known public key authenticator, ignores cert completely.
            _x509_knownkey = (br_x509_knownkey_context *)esp_sslclient_malloc(sizeof(br_x509_knownkey_context));
            if (!_x509_knownkey)
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("OOM for _x509_knownkey"), _debug_level, esp_ssl_debug_error, __func__);
#endif
                return false;
            }
            if (_knownkey->isRSA())
            {
                br_x509_knownkey_init_rsa(_x509_knownkey, _knownkey->getRSA(), _knownkey_usages);
            }
            else if (_knownkey->isEC())
            {
#ifndef BEARSSL_SSL_BASIC
                br_x509_knownkey_init_ec(_x509_knownkey, _knownkey->getEC(), _knownkey_usages);
#else
                (void)_knownkey;
                (void)_knownkey_usages;
                esp_ssl_debug_print(PSTR("Attempting to use EC keys in minimal cipher mode (no EC)"), _debug_level, esp_ssl_debug_error, __func__);
                return false;
#endif
            }
            br_ssl_engine_set_x509(_eng, &_x509_knownkey->vtable);

#else // STATIC_X509_CONTEXT

            // Simple, pre-known public key authenticator, ignores cert completely.
            if (_knownkey->isRSA())
            {
                br_x509_knownkey_init_rsa(&_x509_knownkey, _knownkey->getRSA(), _knownkey_usages);
            }
            else if (_knownkey->isEC())
            {
#ifndef BEARSSL_SSL_BASIC
                br_x509_knownkey_init_ec(&_x509_knownkey, _knownkey->getEC(), _knownkey_usages);
#else
                (void)_knownkey;
                (void)_knownkey_usages;
                esp_ssl_debug_print(PSTR("Attempting to use EC keys in minimal cipher mode (no EC)"), _debug_level, esp_ssl_debug_error, __func__);
                return false;
#endif
            }
            br_ssl_engine_set_x509(_eng, &_x509_knownkey.vtable);

#endif // STATIC_X509_CONTEXT
        }
        else
        {
#if !defined(STATIC_X509_CONTEXT)
            // X509 minimal validator.  Checks dates, cert chain for trusted CA, etc.
            _x509_minimal = (br_x509_minimal_context *)esp_sslclient_malloc(sizeof(br_x509_minimal_context));

            if (!_x509_minimal)
            {
#if defined(ENABLE_DEBUG)
                esp_ssl_debug_print(PSTR("OOM for _x509_minimal"), _debug_level, esp_ssl_debug_error, __func__);
#endif
                return false;
            }
            
            br_x509_minimal_init(_x509_minimal, &br_sha256_vtable, _internal_ta ? _internal_ta->getTrustAnchors() : (_ta ? _ta->getTrustAnchors() : nullptr), _internal_ta? _internal_ta->getCount() : (_ta ? _ta->getCount() : 0));
            br_x509_minimal_set_rsa(_x509_minimal, br_ssl_engine_get_rsavrfy(_eng));
#ifndef BEARSSL_SSL_BASIC
            br_x509_minimal_set_ecdsa(_x509_minimal, br_ssl_engine_get_ec(_eng), br_ssl_engine_get_ecdsa(_eng));
#endif
            bssl::br_x509_minimal_install_hashes(_x509_minimal);

#if (defined(ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_RP2040)) && !defined(ARDUINO_NANO_RP2040_CONNECT)
            if (_now < ESP_SSLCLIENT_VALID_TIMESTAMP)
                _now = time(nullptr);
#endif
            if (_now)
            {
                // Magic constants convert to x509 times
                br_x509_minimal_set_time(_x509_minimal, ((uint32_t)_now) / 86400 + 719528, ((uint32_t)_now) % 86400);
            }
#if defined(ENABLE_FS)
            if (_certStore)
            {
                _certStore->installCertStore(_x509_minimal);
            }
#endif
            br_ssl_engine_set_x509(_eng, &_x509_minimal->vtable);

#else // STATIC_X509_CONTEXT

            // X509 minimal validator.  Checks dates, cert chain for trusted CA, etc.
            br_x509_minimal_init(&_x509_minimal, &br_sha256_vtable, _internal_ta ? _internal_ta->getTrustAnchors() : (_ta ? _ta->getTrustAnchors() : nullptr), _internal_ta ? _internal_ta->getCount() : (_ta ? _ta->getCount() : 0));

            br_x509_minimal_set_rsa(&_x509_minimal, br_ssl_engine_get_rsavrfy(_eng));
#ifndef BEARSSL_SSL_BASIC
            br_x509_minimal_set_ecdsa(&_x509_minimal, br_ssl_engine_get_ec(_eng), br_ssl_engine_get_ecdsa(_eng));
#endif
            bssl::br_x509_minimal_install_hashes(&_x509_minimal);

#if (defined(ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_RP2040)) && !defined(ARDUINO_NANO_RP2040_CONNECT)
            if (_now < ESP_SSLCLIENT_VALID_TIMESTAMP)
                _now = time(nullptr);
#endif
            if (_now)
            {
                // Magic constants convert to x509 times
                br_x509_minimal_set_time(&_x509_minimal, ((uint32_t)_now) / 86400 + 719528, ((uint32_t)_now) % 86400);
            }
#if defined(ENABLE_FS)
            if (_certStore)
            {
                _certStore->installCertStore(_x509_minimal.get());
            }
#endif
            br_ssl_engine_set_x509(_eng, &_x509_minimal.vtable);
#endif // STATIC_X509_CONTEXT
        }
#endif // SSLCLIENT_INSECURE_ONLY
        return true;
    }

    void mFreeSSL()
    {
#if !defined(STATIC_SSLCLIENT_CONTEXT)
        if (_sc)
            esp_sslclient_free((br_ssl_client_context **)&_sc);
#endif
        // _eng is an alias, so it is handled by the overall memory sweep.

#if !defined(STATIC_X509_CONTEXT)

        // Check and free dynamically allocated X509 contexts

#if !defined(SSLCLIENT_INSECURE_ONLY)
        if (_x509_minimal)
            esp_sslclient_free((uint8_t **)&_x509_minimal);

        if (_x509_knownkey)
            esp_sslclient_free((uint8_t **)&_x509_knownkey);
#endif

        if (_x509_insecure)
            esp_sslclient_free((uint8_t **)&_x509_insecure);

#endif

#if !defined(STATIC_IN_BUFFER_SIZE)
        // Check and free dynamically allocated input buffer
        if (_iobuf_in)
            esp_sslclient_free((unsigned char **)&_iobuf_in);
#endif
#if !defined(STATIC_OUT_BUFFER_SIZE) && !defined(SSLCLIENT_HALF_DUPLEX)
        // Check and free dynamically allocated output buffer
        if (_iobuf_out)
            esp_sslclient_free((unsigned char **)&_iobuf_out);
#endif

        // Reset non-allocated ptrs (pointing to bits potentially free'd above)
        _recvapp_buf = nullptr;
        _recvapp_len = 0;

        // This connection is toast
        _handshake_done = false;
        _timeout_ms = 15000;
        _secure = false;
        _is_connected = false;
    }

#if !defined(__AVR__)
    uint8_t *mStreamLoad(Stream &stream, size_t size)
    {
        uint8_t *dest = reinterpret_cast<uint8_t *>(esp_sslclient_malloc(size + 1));
        if (!dest)
        {
            return nullptr;
        }
        if (size != stream.readBytes(dest, size))
        {
            esp_sslclient_free(&dest);
            return nullptr;
        }
        dest[size] = '\0';
        return dest;
    }
#endif

    // store whether to enable debug logging
    int _debug_level = 0;

    bool _is_connected = false;

    //  store the index of where we are writing in the buffer
    //  so we can send our records all at once to prevent
    //  weird timing issues
    size_t _write_idx = 0;

    // store the last BearSSL state so we can print changes to the console
    unsigned int _bssl_last_state = 0;

    bool _secure = false;

    Client *_basic_client = nullptr;

#if defined(STATIC_SSLCLIENT_CONTEXT)
    br_ssl_client_context _sc;
#else
    br_ssl_client_context *_sc = nullptr;
#endif

    br_ssl_engine_context *_eng = nullptr; // &_sc->eng, to allow for client or server contexts

#if defined(SSLCLIENT_INSECURE_ONLY)

#if defined(STATIC_X509_CONTEXT)
    bssl::br_x509_insecure_context _x509_insecure;
#else
    bssl::br_x509_insecure_context *_x509_insecure = nullptr;
#endif

#else

#if defined(STATIC_X509_CONTEXT)
    br_x509_minimal_context _x509_minimal;
    bssl::br_x509_insecure_context _x509_insecure;
    br_x509_knownkey_context _x509_knownkey;
#else
    br_x509_minimal_context *_x509_minimal = nullptr;
    bssl::br_x509_insecure_context *_x509_insecure = nullptr;
    br_x509_knownkey_context *_x509_knownkey = nullptr;
#endif

#endif

#if defined(STATIC_IN_BUFFER_SIZE)

#if STATIC_IN_BUFFER_SIZE < 512
#undef STATIC_IN_BUFFER_SIZE
#define STATIC_IN_BUFFER_SIZE 512
#endif
    unsigned char _iobuf_in[STATIC_IN_BUFFER_SIZE];
#else
    unsigned char *_iobuf_in = nullptr;
#endif

#if !defined(SSLCLIENT_HALF_DUPLEX)
#if defined(STATIC_OUT_BUFFER_SIZE)

#if STATIC_OUT_BUFFER_SIZE < 512
#undef STATIC_OUT_BUFFER_SIZE
#define STATIC_OUT_BUFFER_SIZE 512
#endif

    unsigned char _iobuf_out[STATIC_OUT_BUFFER_SIZE];
#else
    unsigned char *_iobuf_out = nullptr;
#endif
#endif

    int _iobuf_in_size = 512;
    int _iobuf_out_size = 512;

    uint32_t _now = 0;

#if defined(ENABLE_FS)
    CertStoreBase *_certStore = 0;
#endif

#if !defined(SSLCLIENT_INSECURE_ONLY)
    const X509List *_ta = nullptr;
    X509List *_internal_ta = nullptr;
    // Optional client certificate
    const X509List *_chain = nullptr;
    const PrivateKey *_sk = nullptr;    
    X509List *_internal_chain = nullptr;
    PrivateKey *_internal_sk = nullptr;
#endif
    unsigned int _allowed_usages = 0;
    unsigned int _cert_issuer_key_type = 0;

    // Optional storage space pointer for session parameters
    // Will be used on connect and updated on close
    BearSSL_Session *_session = nullptr;

    bool _use_insecure = false;
    bool _use_fingerprint = false;

    bool _use_self_signed = false;
#if !defined(SSLCLIENT_INSECURE_ONLY)
    uint8_t _fingerprint[20];
    const PublicKey *_knownkey;
#endif
    unsigned int _knownkey_usages = 0;

    // Custom cipher list pointer or nullptr if default
    uint16_t *_cipher_list = nullptr;
    uint8_t _cipher_cnt = 0;

    // TLS ciphers allowed
    uint32_t _tls_min = BR_TLS10;
    uint32_t _tls_max = BR_TLS12;

    bool _handshake_done = false;
    bool _oom_err = false;
    unsigned char *_recvapp_buf = nullptr;
    size_t _recvapp_len;
    // Renameing from _timeout which also defined in parent's Stream class.
    unsigned long _timeout_ms = 15000;
    unsigned long _handshake_timeout = 60000;
    unsigned long _tcp_session_timeout = 0;
    unsigned long _session_ts = 0;
    bool _isSSLEnabled = false;
    char _host[64];
    uint16_t _port = 0;
    IPAddress _ip;
    bool _connect_with_ip = false;
};

#endif

#endif /** BSSL_SSL_Client_H */